package com.tweetapp.user.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.tweetapp.user.entity.User;

@Repository
public interface UserRepository extends MongoRepository<User, String>{

}
