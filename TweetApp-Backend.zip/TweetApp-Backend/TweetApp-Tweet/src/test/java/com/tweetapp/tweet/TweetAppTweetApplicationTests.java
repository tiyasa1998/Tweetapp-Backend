package com.tweetapp.tweet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TweetAppTweetApplicationTests {

	@Test
	void contextLoads() {
	}

}
